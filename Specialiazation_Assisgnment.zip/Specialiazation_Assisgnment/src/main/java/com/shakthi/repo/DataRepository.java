package com.shakthi.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shakthi.entity.Data;

public interface DataRepository extends JpaRepository<Data, Integer> {

}
