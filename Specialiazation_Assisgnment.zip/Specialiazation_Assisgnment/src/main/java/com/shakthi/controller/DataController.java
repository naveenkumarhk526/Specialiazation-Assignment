package com.shakthi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shakthi.entity.Data;
import com.shakthi.service.DataService;

@Controller
@RequestMapping("/data")
public class DataController {
	@Autowired
	private DataService service;
	
	@GetMapping("/form")
	public String load() {
		
		return"DataForm";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute Data data, Model model) {
		Integer id = service.savaData(data);
		model.addAttribute("message","Data " + id+" has been addded succesfully");
		return"DataForm";
	}
	
	@GetMapping("all")
	public String getAll(@RequestParam(required = false)String message, Model model) {
		
		List<Data> list = service.getAllData();
		model.addAttribute("list",list);
		model.addAttribute("message",message);
		return"AllData";
	}
	
	@GetMapping("/delete")
	public String delete(
			@RequestParam Integer id,
			RedirectAttributes attributes
			) 
	{
		service.deleteData(id);
		attributes.addAttribute("message", "Data '"+id+"' deleted");
		return "redirect:all";
	}	

	@GetMapping("/edit")
	public String showEdit(
			@RequestParam Integer id,
			Model model
			) 
	{
		Data data = service.getOneData(id);
		model.addAttribute("data", data);
		return "DataEdit";
	}

	@PostMapping("/update")
	public String update(
			@ModelAttribute Data data,
			RedirectAttributes attributes
			) 
	{
		service.updateData(data);
		String message = "Employee '"+data.getId()+"' Updated";
		attributes.addAttribute("message", message);
		return "redirect:all";
	}
}
