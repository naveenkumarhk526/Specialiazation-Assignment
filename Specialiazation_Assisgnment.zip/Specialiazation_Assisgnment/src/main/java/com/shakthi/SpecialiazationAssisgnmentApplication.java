package com.shakthi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpecialiazationAssisgnmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpecialiazationAssisgnmentApplication.class, args);
	}

}
