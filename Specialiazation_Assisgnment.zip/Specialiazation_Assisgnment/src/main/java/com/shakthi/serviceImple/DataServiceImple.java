package com.shakthi.serviceImple;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shakthi.entity.Data;
import com.shakthi.repo.DataRepository;
import com.shakthi.service.DataService;

@Service
public class DataServiceImple implements DataService {
		@Autowired
		private DataRepository repo;
	@Override
	public Integer savaData(Data data) {
		// TODO Auto-generated method stub
		return repo.save(data).getId();
	}

	@Override
	public List<Data> getAllData() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Data getOneData(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	@Override
	public void deleteData(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

	@Override
	public void updateData(Data data) {
		// TODO Auto-generated method stub
		repo.save(data);
	}

}
