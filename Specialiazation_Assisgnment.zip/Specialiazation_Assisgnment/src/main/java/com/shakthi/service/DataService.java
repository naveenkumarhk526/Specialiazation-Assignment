package com.shakthi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shakthi.entity.Data;

@Service
public interface DataService {
	Integer savaData(Data data);
	
	List<Data> getAllData();
	
	Data getOneData(Integer id);
	
	void deleteData(Integer id);
	
	void updateData(Data emp);
}
